from dataBases.adding import add_user
from dataBases.getValue import getTest_mark
from dataBases.deleter import deleteUser
from dataBases.updating import testMark
# add_user("4566565", "Amber", "Hui")
# add_user("7896548", "Vovaa", "гой")
# deleteUser("7896548")
# print (getTest_mark("4566565"))
testMark("4566565","0809")
# activityMark("4566565")

# print (type(getTest_mark("4566565")))